package scripts.webtest;

import javafx.application.Platform;

public class WebViewApp {

    public void exit() {
        Platform.exit();
    }

    public void log() {
        System.out.println("Logging");
    }
}
