package scripts.webtest;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import netscape.javascript.JSObject;
import org.tribot.script.Script;

import javax.swing.*;

public class test2 extends Script {

    @Override
    public void run() {


        while(true)
            sleep(50);
    }
}
