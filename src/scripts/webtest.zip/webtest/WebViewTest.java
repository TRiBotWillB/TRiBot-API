package scripts.webtest;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javax.swing.*;

public class WebViewTest extends Application {

    public WebViewTest() {

        // We have to start the JFX thread from the EDT otherwise tribot will end it.
        SwingUtilities.invokeLater(() -> {

            new JFXPanel(); // we have to init the toolkit

            Platform.runLater(() -> {
                try {
                    final Stage stage = new Stage();

                    start(stage);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });
    }

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource(" http://ce399228.eu.ngrok.io/webtest.fxml"));

        Scene s = new Scene(root, 800, 600);

        s.setFill(Color.TRANSPARENT);

        //stage.initStyle(StageStyle.TRANSPARENT);
        stage.setTitle("WEB");
        stage.setScene(s);

        stage.show();
    }
}
