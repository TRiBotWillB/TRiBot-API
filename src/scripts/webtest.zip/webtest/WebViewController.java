package scripts.webtest;

import javafx.fxml.FXML;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import netscape.javascript.JSObject;

public class WebViewController {

    @FXML
    public WebView web;

    public void initialize() {
        WebEngine engine = web.getEngine();

        engine.load("http://localhost/miner-gui");
        engine.setJavaScriptEnabled(true);

        JSObject window = (JSObject) engine.executeScript("window");


        window.setMember("app", new WebViewApp());

    }
}
